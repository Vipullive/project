import React from "react";
import Layout from "./Layout";

function Policy() {
  return <Layout>Policy</Layout>;
}

export default Policy;
